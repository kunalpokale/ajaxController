﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //I am writing this article on 9th January 2015

        //Selection Date Start from 09th Jan 2005
        Calendar1.StartDate = DateTime.Now.AddYears(-11);
        
        //Current date can be select but not future date.
        Calendar1.EndDate = DateTime.Now;

    }
}